package de.trc.TRC_JoinLeaveMessage.mixins;

import de.trc.TRC_JoinLeaveMessage.Config;
import net.minecraft.class_2535;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import net.minecraft.class_8792;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3324.class)
public class JoinLeaveMixin {

    @Shadow @Final private MinecraftServer server;

    @Inject(method = "broadcast(Lnet/minecraft/text/Text;Z)V", at = @At("HEAD"), cancellable = true)
    private void hideVanilla(class_2561 message, boolean overlay, CallbackInfo ci) {

        if (message.method_10851() instanceof class_2588 translatable) {

            String key = translatable.method_11022();

            if (key.equals("multiplayer.player.joined")
                    || key.equals("multiplayer.player.left")
                    || key.equals("multiplayer.player.joined.renamed")) {

                ci.cancel();
            }
        }
    }

    @Inject(method = "onPlayerConnect", at = @At("TAIL"))
    private void onJoin(class_2535 connection, class_3222 player, class_8792 data, CallbackInfo ci) {

        String name = player.method_5477().getString();
        String message = Config.JoinMessage;

        if (message.contains("%player%")) {
            message = message.replace("%player%", name);
        }

        broadcast(class_2561.method_43470(message));
    }

    @Inject(method = "remove", at = @At("HEAD"))
    private void onLeave(class_3222 player, CallbackInfo ci) {

        String name = player.method_5477().getString();
        String message = Config.LeaveMessage;

        if (message.contains("%player%")) {
            message = message.replace("%player%", name);
        }

        broadcast(class_2561.method_43470(message));
    }

    @Unique
    private void broadcast(class_2561 text) {
        if (server == null) return;
        server.method_3760().method_43514(text, false);
    }
}
